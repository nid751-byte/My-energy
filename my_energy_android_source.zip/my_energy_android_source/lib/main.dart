import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const MyEnergyApp());

class MyEnergyApp extends StatelessWidget {
  const MyEnergyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'My Energy', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff176b62)), useMaterial3: true),
    home: const EnergyHome(),
  );
}

class PricePoint {
  final DateTime time;
  final double sekPerKwh;
  PricePoint(this.time, this.sekPerKwh);
}

class EnergyHome extends StatefulWidget {
  const EnergyHome({super.key});
  @override
  State<EnergyHome> createState() => _EnergyHomeState();
}

class _EnergyHomeState extends State<EnergyHome> {
  List<PricePoint> prices = [];
  bool loading = true;
  String? error;
  double gridFeeOre = 44.5;
  double energyTaxOreExVat = 36.0;
  double markupOre = 0;
  static const double vat = 0.25;

  @override
  void initState() { super.initState(); loadPrices(); }

  Future<void> loadPrices() async {
    setState(() { loading = true; error = null; });
    try {
      final now = DateTime.now();
      final date = '${now.year}/${now.month.toString().padLeft(2,'0')}-${now.day.toString().padLeft(2,'0')}';
      final uri = Uri.parse('https://www.elprisetjustnu.se/api/v1/prices/${date}_SE3.json');
      // API date format is YYYY/MM-DD; SE3 is the Stockholm price area.
      final response = await http.get(uri).timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) throw Exception('Prisservern svarade ${response.statusCode}');
      final data = jsonDecode(response.body) as List;
      final parsed = data.map((e) {
        final m = e as Map<String, dynamic>;
        final raw = (m['SEK_per_kWh'] as num).toDouble();
        return PricePoint(DateTime.parse(m['time_start'] as String), raw);
      }).toList()..sort((a,b) => a.time.compareTo(b.time));
      if (!mounted) return;
      setState(() { prices = parsed; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; error = e.toString(); });
    }
  }

  double totalPrice(PricePoint p) => (p.sekPerKwh * 100 + markupOre) * (1 + vat) / 100 + energyTaxOreExVat * (1 + vat) / 100 + gridFeeOre / 100;

  @override
  Widget build(BuildContext context) {
    final latest = prices.isEmpty ? null : prices.last;
    return Scaffold(
      appBar: AppBar(title: const Text('My Energy'), actions: [IconButton(onPressed: loadPrices, icon: const Icon(Icons.refresh), tooltip: 'Uppdatera priser')]),
      body: RefreshIndicator(onRefresh: loadPrices, child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Elområde SE3', style: TextStyle(fontSize: 15, color: Colors.black54)),
          const SizedBox(height: 8),
          if (loading) const LinearProgressIndicator(),
          if (latest != null) Text('${(latest.sekPerKwh * 100).toStringAsFixed(1)} öre/kWh', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          if (latest != null) Text('Senast tillgängliga pris • ${TimeOfDay.fromDateTime(latest.time).format(context)}'),
          if (error != null) Text('Kunde inte hämta elpriser: $error'),
        ]))),
        const SizedBox(height: 12),
        const Text('Prisöversikt', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (prices.isNotEmpty) SizedBox(height: 170, child: CustomPaint(painter: PriceChart(prices.map((p) => p.sekPerKwh * 100).toList()), child: const SizedBox.expand())),
        const SizedBox(height: 12),
        const Text('Beräknat totalpris', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Preliminär beräkning inklusive moms, energiskatt och nätavgift. Telinets eventuella övriga rörliga avgifter ingår inte.'),
        const SizedBox(height: 8),
        ...prices.reversed.take(24).map((p) => Card(child: ListTile(
          dense: true,
          title: Text('${p.time.day}/${p.time.month}  ${TimeOfDay.fromDateTime(p.time).format(context)}'),
          subtitle: Text('Spot ${ (p.sekPerKwh * 100).toStringAsFixed(1)} öre/kWh'),
          trailing: Text('${(totalPrice(p) * 100).toStringAsFixed(1)} öre/kWh', style: const TextStyle(fontWeight: FontWeight.bold)),
        ))),
        const SizedBox(height: 16),
        const Text('Förbrukning från Saveeye', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Saveeye är ännu inte anslutet. Appen visar elpriser tills säker åtkomst till mätardata finns.'),
        const SizedBox(height: 16),
        ExpansionTile(title: const Text('Tariffinställningar'), children: [
          _setting('Nätavgift inkl. moms (öre/kWh)', gridFeeOre, (v) => setState(() => gridFeeOre = v)),
          _setting('Energiskatt exkl. moms (öre/kWh)', energyTaxOreExVat, (v) => setState(() => energyTaxOreExVat = v)),
          _setting('Påslag (öre/kWh)', markupOre, (v) => setState(() => markupOre = v)),
        ]),
      ])),
    );
  }

  Widget _setting(String label, double value, ValueChanged<double> changed) => ListTile(
    title: Text(label), subtitle: Slider(value: value.clamp(0, 100), min: 0, max: 100, divisions: 100, label: value.toStringAsFixed(1), onChanged: changed),
  );
}

class PriceChart extends CustomPainter {
  final List<double> values;
  PriceChart(this.values);
  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    final minV = values.reduce((a,b) => a < b ? a : b);
    final maxV = values.reduce((a,b) => a > b ? a : b);
    final span = (maxV - minV).abs() < 0.1 ? 1.0 : maxV - minV;
    final path = Path();
    for (var i=0; i<values.length; i++) {
      final x = values.length == 1 ? 0.0 : i * size.width / (values.length - 1);
      final y = size.height - ((values[i] - minV) / span) * (size.height - 12) - 6;
      if (i == 0) { path.moveTo(x,y); } else { path.lineTo(x,y); }
    }
    canvas.drawPath(path, Paint()..color = const Color(0xff176b62)..style = PaintingStyle.stroke..strokeWidth = 3..strokeCap = StrokeCap.round);
  }
  @override
  bool shouldRepaint(covariant PriceChart oldDelegate) => oldDelegate.values != values;
}
