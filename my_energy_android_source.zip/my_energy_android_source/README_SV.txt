MY ENERGY - ANDROID KÄLLKOD

Detta är ett Flutter-källkodsprojekt, inte en färdig APK.
Projektet visar spotpriser för elområde SE3 och en preliminär kostnadsberäkning.
Saveeye är inte anslutet ännu. Integration kräver giltig SDK-nyckel och JWT-autentisering.

Byggs i GitHub Actions med Flutter. Android-plattformens projektfiler behöver genereras
med kommandot: flutter create --platforms=android .

Viktigt: kontrollera alltid aktuella nätavgifter, energiskatt och elhandelsavtal innan
appen används för fakturakontroll. Eventuella övriga rörliga avgifter från elhandlaren
är inte inkluderade i den preliminära beräkningen.
